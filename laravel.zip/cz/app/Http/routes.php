<?php 

Route::get('/TestController@index');

Routr::get('test' function()
{
	return 'get请求';
});

 ?>