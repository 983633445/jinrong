<?php 

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

/**
* 登录控制器
*/
class TestController extends Controller
{
	// 登录页面
	public function index()
	{
		echo '123';
	}
}