<?php 

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

/**
* 
*/
class TestController extends Controller
{
	public function index()
	{
		return view('admin.login');
	}
	public function add(Request $request)
	{
		$username = $request->input('username');

		$password = $request->input('password');

		// $userId = 1;
		/*// 添加数据
		$res = DB::table('user')->insert(
			[
				'username' => $username,
				'password' => $password,
			]
		);
		print_r($res);*/
		/*// 查询单条数据
		$userInfo = DB::table('user')->where('username',$username)->where('password',$password)->first();
		print_r($userInfo);*/
		/*// 修改数据
		$res = Db::table('user')->where('userId',$userId)->update(['username'=>$username,'password'=>'123456']);
		print_r($res);*/
		// 删除数据
		$res = Db::table('user')->where('userId',3)->delete();
		print_r($res);
	}
}

 ?>